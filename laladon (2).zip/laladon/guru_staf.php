﻿<?php
include 'koneksi.php';
include 'header.php';
?>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <div class="row py-5">
            <div class="col-12 text-center">
                <h1 class="page-header-title">Guru & Staf</h1>
                <p class="page-header-subtitle">Para pendidik profesional SDN Laladon 03</p>
            </div>
        </div>
    </div>
</section>

<!-- Teachers Section -->
<section class="py-5" style="background-color: #f8f9fc;">
    <div class="container">
        <div class="section-title-wrapper">
            <h2 class="section-title mt-2">Tim Pengajar & Staf Profesional</h2>
            <div class="section-divider"></div>
            <p class="section-desc">Para pendidik berpengalaman yang berdedikasi tinggi untuk membentuk karakter dan kecerdasan peserta didik.</p>
        </div>

        <div class="row g-4">
            <?php
            $query_teachers = "SELECT * FROM teachers ORDER BY id ASC";
            $result_teachers = mysqli_query($koneksi, $query_teachers);

            if (mysqli_num_rows($result_teachers) > 0):
                $delay = 1;
                while ($row = mysqli_fetch_assoc($result_teachers)):
            ?>
            <div class="col-md-6 col-lg-3 fade-delay-<?php echo min($delay, 4); ?>">
                <div class="teacher-card">
                    <div class="teacher-card-img-wrap">
                        <img src="<?php echo htmlspecialchars($row['photo']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <div class="teacher-card-overlay"></div>
                    </div>
                    <div class="teacher-badge-wrap">
                        <span class="teacher-badge">Pendidik</span>
                    </div>
                    <div class="teacher-card-body">
                        <h5 class="teacher-name"><?php echo htmlspecialchars($row['name']); ?></h5>
                        <p class="teacher-position"><?php echo htmlspecialchars($row['position']); ?></p>
                        <p class="teacher-bio"><?php echo htmlspecialchars($row['bio']); ?></p>
                    </div>
                </div>
            </div>
            <?php
                $delay++;
                endwhile;
            else:
            ?>
            <div class="col-12">
                <div class="news-empty-state">
                    <div class="empty-icon">
                        <i data-lucide="users" style="width:36px;height:36px;color:#d1d5db;"></i>
                    </div>
                    <h5 class="fw-bold mb-2" style="color:#6b7280;">Data Belum Tersedia</h5>
                    <p class="text-muted">Data guru dan staf belum ditambahkan.</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <div style="background:linear-gradient(135deg,#1a1a2e,#16213e);border-radius:24px;padding:3rem 2rem;">
                    <div style="width:64px;height:64px;background:linear-gradient(135deg,#FFD700,#FFA500);border-radius:18px;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;">
                        <i data-lucide="mail" style="width:28px;height:28px;color:#3d1f00;"></i>
                    </div>
                    <h3 class="fw-bold text-white mb-2">Bergabung Bersama Kami</h3>
                    <p style="color:rgba(255,255,255,0.7);margin-bottom:1.75rem;font-size:0.95rem;">
                        Tertarik bergabung sebagai pendidik di SDN Laladon 03? Kami selalu membuka peluang bagi individu yang berdedikasi dan berpassion dalam dunia pendidikan.
                    </p>
                    <a href="mailto:sdnlaladon03@gmail.com" class="btn" style="background:linear-gradient(135deg,#FFD700,#FFA500);color:#3d1f00;font-weight:700;border-radius:50px;padding:0.75rem 2rem;">
                        <i data-lucide="send" class="me-2" style="width:16px;height:16px;"></i>
                        Hubungi Kami
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
