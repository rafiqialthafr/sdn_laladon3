<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDN Laladon 03 - Sekolah Ramah Anak</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome removed, using Lucide Icons -->
    <link rel="stylesheet" href="style.css/main.css">
    <link rel="stylesheet" href="style.css/responsive.css">
    <link rel="stylesheet" href="style.css/animations.css">
</head>
<body>



<!-- Main Navbar -->
<nav id="mainNavbar" class="navbar navbar-expand-lg navbar-light bg-white sticky-top py-2">
    <div class="container-fluid px-3 px-lg-4">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="logo.jpeg" alt="Logo" width="50" height="50" class="me-2">
            <div>
                <span class="brand-text">SDN LALADON 03</span>
            </div>
        </a>
        <button class="hamburger-btn" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="hb-bar hb-top"></span>
            <span class="hb-bar hb-mid"></span>
            <span class="hb-bar hb-bot"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item">
                    <a class="nav-link" href="index.php"><i data-lucide="home" class="me-2"></i>Beranda</a>
                </li>
                <li class="nav-item dropdown">

                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"><i data-lucide="graduation-cap" class="me-2"></i>
                        Profil
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="sejarah.php"><i data-lucide="compass" class="me-2"></i>Sejarah Singkat</a></li>
                        <li><a class="dropdown-item" href="visimisi.php"><i data-lucide="rocket" class="me-2"></i>Visi Misi</a></li>
                        <li><a class="dropdown-item" href="kepala_sekolah.php"><i data-lucide="user" class="me-2"></i>Kepala Sekolah</a></li>
                        <li><a class="dropdown-item" href="guru_staf.php"><i data-lucide="users" class="me-2"></i>Guru dan Staf</a></li>
                        <li><a class="dropdown-item" href="fasilitas.php"><i data-lucide="building-2" class="me-2"></i>Fasilitas</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="berita.php"><i data-lucide="newspaper" class="me-2"></i>Berita</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php"><i data-lucide="mail" class="me-2"></i>Kontak</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"><i data-lucide="share-2" class="me-2"></i>
                        Link
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#"><i data-lucide="facebook" class="me-2"></i> Facebook</a></li>
                        <li><a class="dropdown-item" href="https://www.instagram.com/sdnlaladonnnn03?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener noreferrer"><i data-lucide="instagram" class="me-2"></i> Instagram</a></li>
                        <li><a class="dropdown-item" href="https://www.youtube.com/@SDNLaladon03" target="_blank" rel="noopener noreferrer"><i data-lucide="youtube" class="me-2"></i> YouTube</a></li>
                        <li><a class="dropdown-item" href="#"><i data-lucide="music" class="me-2"></i> Tiktok</a></li>
                    </ul>
                
            </ul>
        </div>
    </div>
</nav>


